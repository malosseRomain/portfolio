#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#include <array>
#ifdef _WIN32
#define NOMINMAX
#include <Windows.h>
#endif // _WIN32

int main()
{
#ifdef _WIN32
    SetConsoleCP(CP_UTF8);
    SetConsoleOutputCP(CP_UTF8);
#endif // _WIN32
    std::cout << "entrer le nom du fichier a traiter : ";
    std::string fichier;
    std::getline(std::cin, fichier);
    std::ifstream in(fichier, std::ios_base::binary);
    if (!in.is_open())
        std::cerr << "Probleme d'ouverture du fichier " << fichier << ".\n";

    std::vector<std::string>entetes;
    std::string ligne;
    for (int i = 0; i < 4; i++)
    {
        std::getline(in, ligne);
        if (ligne[0] != '#')
        {
            entetes.push_back(ligne);
        }
    }
    for (auto elem : entetes)
        std::cout << elem << '\n';


    std::stringstream sstr(entetes[1]);
    std::string ch1;
    std::getline(sstr, ch1, ' ');
    int largeur = stoi(ch1);


    std::vector<char> goodpalette1 = { 'W','w','l','i',':',',','.',' ' };     //palette s�r elle marche 
    std::vector<std::string> goodpalette = {};
    std::string palette;
    std::cout << "entrer le fichier de votre palette : ";
    std::getline(std::cin, palette);
    std::ifstream palettein(palette);
    if (!palettein.is_open())
        std::cerr << "Probleme d'ouverture du fichier " << palette << ".\n";
    while (palettein.eof() == false) {
        std::getline(palettein, ligne);
        goodpalette.push_back(ligne);
    }



    std::cout << "entrer le nom du fichier a extraire : ";
    std::string fichierout;
    std::getline(std::cin, fichierout);
    std::ofstream out(fichierout, std::ios::binary);
    size_t taillepalette = goodpalette.size();
    if (!out.is_open())
        std::cerr << "Probleme d'ouverture du fichier \"Ascii art\".\n";

    float pas = 256 / taillepalette;
    while (in.eof() == false)
    {
        for (int j = 0; j < largeur; j++) {
            std::vector<char> donnees(1);
            in.read(donnees.data(), 1);

            for (unsigned char elem : donnees) {

                int y = 0;
                for (int i = 0; i < 256; i += pas) {
                    if (elem > i && elem < i + pas) {
                        out << goodpalette[y];
                        std::cout << goodpalette[y];
                        break;
                    }
                    y++;
                }

            }
        }
        out << "\n";
        std::cout << '\n';
    }
}