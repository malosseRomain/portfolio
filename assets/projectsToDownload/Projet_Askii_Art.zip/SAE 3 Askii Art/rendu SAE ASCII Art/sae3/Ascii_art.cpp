#include "Ascii_art.h"

std::string ascci_art()
{
	return 0;
}