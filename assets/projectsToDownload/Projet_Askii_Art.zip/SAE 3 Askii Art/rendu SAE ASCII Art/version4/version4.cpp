#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#include <array>
#ifdef _WIN32
#define NOMINMAX
#include <Windows.h>
#endif // _WIN32

int main(int argc, char* argr[])
{
#ifdef _WIN32
    SetConsoleCP(CP_UTF8);
    SetConsoleOutputCP(CP_UTF8);
#endif // _WIN32
    std::vector<std::string> argv;
    for (int i = 0; i < argc; i++) {
        argv.push_back(argr[i]);
    }
    //on met les arguments de la fonction dans un vector de string

    if (argv[1] == "--help") {
        std::cout << "Usage :\n"
            "pgm2txt[options]\n"
            "Options :\n"
            "--input fichier Spécifie le fichier image à convertir\n"
            "                 Si ce paramètre n'est pas spécifié, le fichier est demandé via la console.\n\n"
            "--output fichier Spécifie le nom du fichier texte qui contiendra l'Ascii Art.\n"
            "                 Si ce paramètre n'est pas spécifié, l'Ascii Art est sortie dans la console.\n\n"
            "--palette fichier Spécifie un fichier texte contenant la palette de couleur Ascii.\n"
            "                  Chaque ligne du fichier contient un charactère en UTF - 8, du plus sombre au plus clair.\n"
            "                  Si ce paramètre n'est pas spécifié, la palette par défaut est\n"
            "                  W, w, l, i, :, , , .,  \n\n"
            "--help            Affiche cette aide.\n";
    }
    //on renvoie un message d'aide de la fonction si le premiere argument est --help car on va pas demander de l'aide sur une fonction en meme temps de l'utiliser
    std::string input;
    for (int a = 1; a < argc; a += 2) {
        if (argv[a] == "--input") {
            input = argv[a + 1]+".txt";
            std::ifstream in(argv[a+1], std::ios::binary);
            if (!in.is_open())
                std::cerr << "Probleme d'ouverture du fichier .\n";

            std::vector<std::string>entetes;
            std::string ligne;
            for (int i = 0; i < 4; i++)
            {
                std::getline(in, ligne);
                if (ligne[0] != '#')
                {
                    entetes.push_back(ligne);
                }
            }
            for (auto elem : entetes)
                std::cout << elem << std::endl;


            std::stringstream sstr(entetes[1]);
            std::string ch1;
            std::getline(sstr, ch1, ' ');
            int largeur = stoi(ch1);
            std::vector<std::string> goodpalette = {};
            std::ifstream palettein("palette.txt");
            if (!palettein.is_open())
                std::cerr << "Probleme d'ouverture du fichier palette.txt.\n";
            while (palettein.eof() == false) {
                std::getline(palettein, ligne);
                goodpalette.push_back(ligne);
            }
            for (int b = 1; b < argc; b += 2) {
                if (argv[b] == "--palette") {
                        goodpalette.resize(0);
                    std::ifstream palettein(argv[b + 1]);
                    if (!palettein.is_open())
                        std::cerr << "Probleme d'ouverture du fichier " << argv[b + 1] << ".\n";
                    while (palettein.eof() == false) {
                        std::getline(palettein, ligne);
                        goodpalette.push_back(ligne);
                    }
                }
            }
            for (int b = 1; b < argc; b += 2) {
                if (argv[b] != "--output") {
                    std::ofstream out(input, std::ios::binary);
                    size_t taillepalette = goodpalette.size();
                    if (!out.is_open())
                        std::cerr << "Probleme d'ouverture du fichier" << input << " .\n";
                    float pas = 256 / taillepalette;
                    while (!in.eof())
                    {
                        for (int j = 0; j < largeur; j++) {
                            std::vector<char> donnees(1);
                            in.read(donnees.data(), 1);

                            for (unsigned char elem : donnees) {
                                int y = 0;
                                for (int i = 0; i < 256; i += pas) {
                                    if (elem > i && elem < i + pas) {
                                        out << goodpalette[y];
                                        std::cout << goodpalette[y];
                                        break;
                                    }
                                    y++;
                                }
                            }
                        }
                        out << "\n";
                        std::cout << std::endl;

                    }
                }
                else {
                    std::ofstream out(argv[b + 1]);
                    size_t taillepalette = goodpalette.size();
                    if (!out.is_open())
                        std::cerr << "Probleme d'ouverture du fichier " << argv[b + 1] << ". \n";

                    float pas = 256 / taillepalette;
                    while (!in.eof())
                    {
                        for (int j = 0; j < largeur; j++) {
                            std::vector<char> donnees(1);
                            in.read(donnees.data(), 1);

                            for (unsigned char elem : donnees) {

                                int y = 0;
                                for (int i = 0; i < 256; i += pas) {
                                    if (elem > i && elem < i + pas) {
                                        out << goodpalette[y];
                                        std::cout << goodpalette[y];
                                        break;
                                    }
                                    y++;
                                }
                            }
                        }
                        out << "\n";
                        std::cout << std::endl;

                    }
                }
            }
        }
    }
}