#include <iostream>
#include "fonction.h"
#include <fstream>
#include <array>
int main()
{
	std::srand(std::time(0));
	std::ofstream out("output_nbr_comp.csv");
	const int nb_Fct_Init = 5;
	const int nb_Tri_Tester = 4;
	std::array<InitFct, nb_Fct_Init> tabInitFct = { initTabAleat, initTabPresqueTri, initTabPresqueTriDeb, initTabPresqueTriFin, initTabPresqueTriDebFin };// tableau de pointeurs vers fonction g�n�ration de tableau
	std::array<TriFct, nb_Tri_Tester> Nom_Fct_tri = { triSelection, triBulles, triBullesOpti, TriPeigne };// tableau de pointeurs vers fonction de tri
	//pour l affichage de la premiere ligne
	const int nb_Tri_Tester1 = 5;// constante pour avoir le nb de tri avec le tri -rapide
	std::array<std::string, nb_Fct_Init> tabInitName = { "initTabAleat", "initTabPresqueTri", "initTabPresqueTriDeb", "initTabPresqueTriFin", "initTabPresqueTriDebFin" };
	std::array<std::string, nb_Tri_Tester1>  TriName = { "triSelection", "triBulles","triBullesOpti", "TriPeigne", "TriRapide" };
	out << "N,";
	for (int i = 0; i < nb_Tri_Tester1; i++)
	{
		for (int j = 0; j < nb_Fct_Init; j++)
		{
			if (i == (nb_Tri_Tester1 - 1) && j == (nb_Fct_Init - 1))
				out << tabInitName[j] << '(' << TriName[i] << ')' << "\n";
			else
				out << tabInitName[j] << '(' << TriName[i] << ')' << ',';
		}
	}

	unsigned int nbr_comp = 0;
	for (int i = 5; i <= 500; i += 5)
	{
		out << i << ',';
		for (int j = 0; j < nb_Tri_Tester1; j++)
		{
			for (int k = 0; k < nb_Fct_Init; k++) {
				std::vector<int> TabAlea = tabInitFct[k](i);
				if (j == nb_Tri_Tester)
				{
					nbr_comp = 0;
					out << Trirapide(TabAlea, 0, TabAlea.size() - 1, nbr_comp) << ',';
				}
				else
				{
					if (j == nb_Tri_Tester && k == nb_Fct_Init)
					{
						out << Trirapide(TabAlea, 0, TabAlea.size() - 1, nbr_comp);
					}
					else {
						out << Nom_Fct_tri[j](TabAlea) << ',';
					}
				}
			}
		}
		out << "\n";
	};
	std::vector<int> test = initTabAleat(10);
	triInsertion(test);
	for (auto elem : test) {
		std::cout << elem<<' ';
	}
}
