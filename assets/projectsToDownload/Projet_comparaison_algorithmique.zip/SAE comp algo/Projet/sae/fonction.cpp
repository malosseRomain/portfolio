/**
 * \file fonctions.cpp
 *
 * D�finition des fonctions fournies.
 */
#include "fonction.h"
#include <iostream>
#include <stdlib.h>


 /**
  * Cr�e un tableau d'entiers dont tous les �l�ments sont choisis al�atoirement.
  *
  * Un tel tableau peut par exemple �tre 30968 28073 31177 2882 6140 17999 13828 20039 2310 24865.
  *
  * \param[in] N taille du tableau
  * \return le tableau initialis�
  */
std::vector<int> initTabAleat(size_t N)
{
    std::vector<int> tab(N);
    for (auto& val : tab)
        val = rand();
    return tab;
}

/**
 * Cr�e un tableau d'entiers presque tri�s. Chaque �l�ment est quasiment � sa place d�finitive, �chang� �ventuellement d'une place.
 *
 * Un tel tableau peut par exemple �tre 1 3 2 4 6 5 8 7 9 10.
 *
 * \param[in] N taille du tableau
 * \return le tableau initialis�
 */
std::vector<int> initTabPresqueTri(size_t N)
{
    std::vector<int> tab(N);
    for (int i = 0; i < N; i++)
        tab[i] = i;
    for (int i = 0; i < N - 1; i++)
    {
        if (rand() % 2 == 0)
        {
            std::swap(tab[i], tab[i + 1]);
            ++i;
        }
    }
    return tab;
}

/**
 * Cr�e un tableau d'entiers presque tri�s. Seuls le premier et le deuxi�me �l�ment sont �chang�s.
 *
 * Un tel tableau peut par exemple �tre 2 1 3 4 5 6 7 8 9 10.
 *
 * \param[in] N taille du tableau
 * \return le tableau initialis�
 */
std::vector<int> initTabPresqueTriDeb(size_t N)
{
    std::vector<int> tab(N);
    for (int i = 0; i < N; i++)
        tab[i] = i;
    std::swap(tab[0], tab[1]);
    return tab;
}

/**
 * Cr�e un tableau d'entiers presque tri�s. Seuls le dernier et l'avant dernier �l�ment sont �chang�s.
 *
 * Un tel tableau peut par exemple �tre 1 2 3 4 5 6 7 8 10 9.
 *
 * \param[in] N taille du tableau
 * \return le tableau initialis�
 */
std::vector<int> initTabPresqueTriFin(size_t N)
{
    std::vector<int> tab(N);
    for (int i = 0; i < N; i++)
        tab[i] = i;
    std::swap(tab[N - 1], tab[N - 2]);
    return tab;
}

/**
 * Cr�e un tableau d'entiers presque tri�s. Seuls le premier et le dernier �l�ment sont �chang�s.
 *
 * Un tel tableau peut par exemple �tre 10 2 3 4 5 6 7 8 9 1.
 *
 * \param[in] N taille du tableau
 * \return le tableau initialis�
 */
std::vector<int> initTabPresqueTriDebFin(size_t N)
{
    std::vector<int> tab(N);
    for (int i = 0; i < N; i++)
        tab[i] = i;
    std::swap(tab[N - 1], tab[0]);
    return tab;
}

/**
 * V�rifie qu'un tableau est correctement tri�. Si le tableau est mal tri�, un message d'erreur est
 * affich� sur le flux d'erreur et le programme est termin�.
 *
 * \param[in] tab Le tableau � v�rifier
 * \param[in] algoName Le nom de l'algorithme de tri qui a �t� utilis�. Ce param�tre est optionnel.
 */
void verifTri(const std::vector<int>& tab, const std::string& algoName)
{
    const size_t taille = tab.size();
    for (size_t i = 1; i < taille; i++)
    {
        if (tab[i - 1] > tab[i])
        {
            std::cerr << "Erreur dans le tri " << algoName << (algoName.empty() ? "!" : " !") << '\n';
            exit(EXIT_FAILURE);
        }
    }
}
//Algorithme de tri par selection
unsigned int triSelection(std::vector<int>& tab) {
    size_t taille = tab.size();
    unsigned int nbr_comp=0;
    std::vector<int> tab_fin;
    for (int i = 0; i < taille - 1; i++) {
       int min = i;
        for (int j = i + 1; j < taille ;j++) {
            if (tab[j] < tab[min]) {
                min = j;
            }
            nbr_comp++;
        }
        if (min != i) {
            std::swap(tab[i], tab[min]);
        }
    }
return nbr_comp;
}
//Algorithme de tri bulles
unsigned int triBulles(std::vector<int>& tab) {
    size_t taille = tab.size() + 1;
    unsigned int nbr_comp = 0;
    for (int i = taille-1; i > 1 ;i--) {
        for (int j = 0; j < i - 1; j++) {
            if (tab[j + 1] < tab[j]) {
                std::swap(tab[j + 1], tab[j]);
            }
            nbr_comp++;
        }
    }
    return nbr_comp;
}
//Algorithme de tri bulles Optimis�
unsigned int triBullesOpti(std::vector<int>& tab) {
    size_t taille = tab.size() + 1;
    unsigned int nbr_comp = 0;
    for (int i = taille - 1; i > 1; i--) {
        bool tab_trie = true;
        for (int j = 0; j < i - 1; j++) {
            if (tab[j + 1] < tab[j]) {
                std::swap(tab[j + 1], tab[j]);
                tab_trie = false;
            }
            nbr_comp++;
            if (tab_trie == true) {
                EXIT_SUCCESS;
            }
            //nbr_comp++;nous sommes pas sures qu'il est n�cessaire de le mettre
        }
    }
    return nbr_comp;
}
//Algorithme de tri Peigne
unsigned int TriPeigne(std::vector<int>& tab)
{
    unsigned int nbr_comp = 0;
    bool �change = false;
    int intervalle = tab.size();
    while (intervalle > 1 || �change == true)
    {
        intervalle /= 1.3;
        if (intervalle < 1)
            intervalle = 1;
        nbr_comp++;
        int i = 0;
        �change = false;
        while (i < tab.size() - intervalle)
        {
            if (tab[i] > tab[i + intervalle])
            {
                std::swap(tab[i], tab[i + intervalle]);
                �change = true;
            }
            nbr_comp++;
            i += 1;
        }
    }
    return nbr_comp;
}

//Algorithme de tri Rapide
int partitionner(std::vector<int>& tab, int premier, int dernier, int pivot,unsigned int& nbr_comp) {
    std::swap(tab[pivot], tab[dernier]);
    int j = premier;
    for (int i = premier; i <dernier; i++) {
        if (tab[i] <= tab[dernier]) {
            std::swap(tab[i], tab[j]);
            j++;
        }
        nbr_comp++;
    }
    std::swap(tab[dernier], tab[j]);
    return j;
};
int choix_pivot(int premier,int dernier) {
    int pivot = (dernier - premier + 1) * std::rand() / (RAND_MAX + 1) + premier;
    return pivot;
}

unsigned int Trirapide(std::vector<int>& tab, int premier, int dernier,unsigned int& nbr_comp) {
    if (premier < dernier) {
        int pivot = choix_pivot(premier,dernier);
        pivot = partitionner(tab, premier, dernier, pivot,nbr_comp);
        Trirapide(tab, premier, pivot - 1, nbr_comp);
        Trirapide(tab, pivot + 1, dernier, nbr_comp);
        
    }
    nbr_comp++;
    return nbr_comp;
}

//Algorithme de tri par insertion
void triInsertion(std::vector<int>& tab) {
    size_t taille = tab.size();
    for (int i = 0; i < taille ; i++) {
        int x = tab[i];
        int j = i;
        while (j > 0 && tab[j - 1] > x) {
            tab[j] = tab[j - 1];
            j -= 1;
        }
        tab[j] = x;
    }
}

//Algorithme de tri Cocktail
void triCocktailOpti(std::vector<int>& tab)
{
    bool echanger = true;
    int debut = 0;
    size_t taille = tab.size();
    int fin = taille - 2;

    while (echanger) {
        echanger = false;
        for (size_t i = debut; i <= fin; i++) {
            if (tab[i] > tab[i + 1]) {
                std::swap(tab[i], tab[i + 1]);
                echanger = true;
            }
        }
        fin--;
        for (size_t j = fin; j > debut; j--) {
            if (tab[j] > tab[j + 1]) {
                std::swap(tab[j], tab[j + 1]);
                echanger = true;
            }
        }
        debut++;
    }
}

//Algorithme de tri Pair Impaire
void triPairImpair(std::vector<int>& tab)
{
    size_t taille = tab.size()-1;
    bool trier = false;

    while (!trier) {
        trier = true;

        for (int i = 0; i < taille ; i += 2) {

            if (tab[i] > tab[i + 1]) {
                std::swap(tab[i], tab[i + 1]);
                trier = false;
            }
        }
        for (int j = 1; j < taille ; j += 2) {

            if (tab[j] > tab[j + 1]) {
                std::swap(tab[j], tab[j + 1]);
                trier = false;
            }
        }
    }
}

//tous les Algorithme ont etaient fait avec comme support le pseudo-code de wikip�dia